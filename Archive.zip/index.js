$('.sliderContainerMain').slick({
	slidesToShow: 1,
	dots: true,
	centerMode: false,
	infinite: false,
	arrows: true,	
})
$('.sliderContainerProduct').slick({
	slidesToShow: 4.3,
	dots: true,
	centerMode: false,
	infinite: false,
	arrows: true,	
})
$('.slidertestimonials').slick({
	slidesToShow: 1,
	dots: false,
	centerMode: false,
	infinite: false,
	arrows: true,	
})